package gifanimation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;

/**
 * @author nguyenduong
 */
public class GifAnimationGUI extends javax.swing.JFrame {
    private ImagePanel imagePanel;
    public GifAnimationGUI() {
        initComponents();
        buildGUI();
    }

    private void buildGUI() {
        imagePanel = new ImagePanel(this);
        this.dispose();
        this.add(imagePanel);
        this.setUndecorated(true);
        this.getContentPane().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        this.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        this.setAlwaysOnTop(true);
        this.setType(JFrame.Type.UTILITY);
        this.setLocationByPlatform(true);
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.pack();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pmOption = new javax.swing.JPopupMenu();
        miIcon = new javax.swing.JMenuItem();
        miExit = new javax.swing.JMenuItem();

        miIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/icon.png"))); // NOI18N
        miIcon.setText("Change Icon");
        miIcon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miIconActionPerformed(evt);
            }
        });
        pmOption.add(miIcon);

        miExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/exit.png"))); // NOI18N
        miExit.setText("Exit");
        miExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miExitActionPerformed(evt);
            }
        });
        pmOption.add(miExit);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void miExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_miExitActionPerformed

    private void miIconActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miIconActionPerformed
        JFileChooser fileSave = new JFileChooser();
        fileSave.setDialogTitle("Open File");
        fileSave.addChoosableFileFilter(new FileTypeFilter(".gif", 
                "Graphic Interchange Format"));
        fileSave.setAcceptAllFileFilterUsed(false);
        try {
            if (fileSave.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                String path = fileSave.getSelectedFile().getAbsolutePath();
                if (!path.isEmpty()) {
                    imagePanel.updateImage(path);
                    imagePanel.repaint();
                    imagePanel.revalidate();
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_miIconActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GifAnimationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(() -> {
            new GifAnimationGUI().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem miExit;
    private javax.swing.JMenuItem miIcon;
    private javax.swing.JPopupMenu pmOption;
    // End of variables declaration//GEN-END:variables

    public class ImagePanel extends JPanel {
        private final JFrame frame;
        private Image image;
        private Point mouseDownCompCoords;
        public ImagePanel(JFrame frame) {
            super.setOpaque(false);
            this.frame = frame;
            mouseEvent();
            getDefaultImage();
        }

        public void updateImage(String path) {
            image = Toolkit.getDefaultToolkit().createImage(path);
        }

        private void getDefaultImage() {
            try {
                BufferedImage bufferedImg = ImageIO.read(this.getClass().getClassLoader().getResource("img/default.png"));
                image = bufferedImg.getScaledInstance(bufferedImg.getWidth(), bufferedImg.getHeight(), Image.SCALE_SMOOTH);
            } catch (IOException | IllegalArgumentException e) {
                JOptionPane.showMessageDialog(frame, e);
                System.exit(0);
            }
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (image != null) {
                g.drawImage(image, 0, 0, this);
            }
        }

        private void mouseEvent() {
            this.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (SwingUtilities.isRightMouseButton(e)) {
                        Point point = e.getPoint();
                        pmOption.show(frame, point.x, point.y);
                    }
                }

                @Override
                public void mousePressed(MouseEvent e) {
                    mouseDownCompCoords = e.getPoint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    mouseDownCompCoords = null;
                }

                @Override
                public void mouseEntered(MouseEvent e) {}

                @Override
                public void mouseExited(MouseEvent e) {}
            });
            this.addMouseMotionListener(new MouseMotionListener() {
                @Override
                public void mouseDragged(MouseEvent e) {
                    Point currCoords = e.getLocationOnScreen();
                    frame.setLocation(currCoords.x - mouseDownCompCoords.x, currCoords.y - mouseDownCompCoords.y);
                }

                @Override
                public void mouseMoved(MouseEvent e) {}
            });
        }
    }

    public class FileTypeFilter extends FileFilter {

        private final String extension;
        private final String description;

        public FileTypeFilter(String extension, String description) {
            this.extension = extension;
            this.description = description;
        }

        @Override
        public boolean accept(File file) {
            if (file.isDirectory()) {
                return true;
            }
            return file.getName().endsWith(extension);
        }

        @Override
        public String getDescription() {
            return description + String.format(" (*%s)", extension);
        }

        public String getExtension() {
            return extension;
        }
    }
}