package javis;

import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.DateFormatSymbols;
import java.util.Calendar;

/**
 * @author Duong Nguyen
 */
public class JavisInformation {
    private int freeCapacity;
    public JavisInformation() {
        
    }

    public String getMonth() {
        int num = Calendar.getInstance().get(Calendar.MONTH);
        return new DateFormatSymbols().getMonths()[num];
    }

    public String getDay() {
        int num = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
        return Integer.toString(num);
    }

    public String getFullCapacity() {
        int capacity = 0;
        freeCapacity = 0;
        long gb = 1024 * 1024 * 1024;
        for (Path root : FileSystems.getDefault().getRootDirectories()) {
            try {
                FileStore store = Files.getFileStore(root);
                freeCapacity += store.getUsableSpace() / gb;
                capacity += store.getTotalSpace() / gb;
            } catch (IOException e) {
            }
        }
        return Integer.toString(capacity) + " GB";
    }

    public String getFreeCapacity() {
        try {
            return Integer.toString(freeCapacity) + " GB";
        } catch (Exception e) {
        }
        return "";
    }

    public static void main(String a[]) {
        JavisInformation javaInformation = new JavisInformation();
        System.out.println(javaInformation.getFullCapacity());
        System.out.println(javaInformation.getFreeCapacity());
    }
}