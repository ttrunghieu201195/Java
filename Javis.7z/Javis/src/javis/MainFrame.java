package javis;

import java.awt.Color;

public class MainFrame extends javax.swing.JFrame {
    private JavisInformation javisInformation;
    public MainFrame() {
        initComponents();
        buildGUI();
    }

    private void buildGUI() {
        this.setSize(1366, 768);
        this.dispose();
        this.setUndecorated(true);
        this.setVisible(true);
        loadImages();
        loadInfo();
        textAnimation();
    }

    private void loadImages() {
        datePanel.loadImage(this.getClass().getClassLoader().getResource("img/CircleDate_n.png").toString());
        fullCapacityPanel.loadImage(this.getClass().getClassLoader().getResource("img/FullCapacity.png").toString());
        freeCapacityPanel.loadImage(this.getClass().getClassLoader().getResource("img/FreeCapacity.png").toString());
    }

    private void loadInfo() {
        javisInformation = new JavisInformation();
        lbMonth.setText(javisInformation.getMonth());
        lbDay.setText(javisInformation.getDay());
        lbFullCapacity.setText(javisInformation.getFullCapacity());
        lbFreeCapacity.setText(javisInformation.getFreeCapacity());
    }

    private void textAnimation() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                try {
                    while (true) {
                        lbFullCapacity.setForeground(Color.decode("#00FEF6"));
                        lbFreeCapacity.setForeground(Color.decode("#00FEF6"));
                        Thread.sleep(1000);
                        lbFullCapacity.setForeground(Color.WHITE);
                        lbFreeCapacity.setForeground(Color.WHITE);
                        Thread.sleep(1000);
                    }
                } catch (Exception e) {
                }
            }
        }; thread.start();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnBackground = new javax.swing.JPanel();
        datePanel = new javis.StaticImagePanel();
        lbMonth = new javax.swing.JLabel();
        lbDay = new javax.swing.JLabel();
        fullCapacityPanel = new javis.DynamicImagePanel();
        freeCapacityPanel = new javis.DynamicImagePanel();
        lbFullCapacity = new javax.swing.JLabel();
        lbFreeCapacity = new javax.swing.JLabel();
        lbBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnBackground.setBackground(new java.awt.Color(255, 255, 255));
        pnBackground.setLayout(null);

        datePanel.setBackground(new java.awt.Color(255, 255, 255));
        datePanel.setMinimumSize(new java.awt.Dimension(185, 185));
        datePanel.setOpaque(false);
        datePanel.setPreferredSize(new java.awt.Dimension(185, 185));

        lbMonth.setFont(new java.awt.Font("Maiandra GD", 1, 24)); // NOI18N
        lbMonth.setForeground(new java.awt.Color(0, 254, 246));
        lbMonth.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbMonth.setText("April");
        lbMonth.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);

        lbDay.setFont(new java.awt.Font("Maiandra GD", 1, 36)); // NOI18N
        lbDay.setForeground(new java.awt.Color(0, 254, 246));
        lbDay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbDay.setText("27");
        lbDay.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        javax.swing.GroupLayout datePanelLayout = new javax.swing.GroupLayout(datePanel);
        datePanel.setLayout(datePanelLayout);
        datePanelLayout.setHorizontalGroup(
            datePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbMonth, javax.swing.GroupLayout.DEFAULT_SIZE, 184, Short.MAX_VALUE)
            .addComponent(lbDay, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        datePanelLayout.setVerticalGroup(
            datePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(datePanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(lbMonth, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(lbDay, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pnBackground.add(datePanel);
        datePanel.setBounds(75, 46, 184, 184);

        fullCapacityPanel.setOpaque(false);

        javax.swing.GroupLayout fullCapacityPanelLayout = new javax.swing.GroupLayout(fullCapacityPanel);
        fullCapacityPanel.setLayout(fullCapacityPanelLayout);
        fullCapacityPanelLayout.setHorizontalGroup(
            fullCapacityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );
        fullCapacityPanelLayout.setVerticalGroup(
            fullCapacityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        pnBackground.add(fullCapacityPanel);
        fullCapacityPanel.setBounds(75, 244, 31, 28);

        freeCapacityPanel.setOpaque(false);

        javax.swing.GroupLayout freeCapacityPanelLayout = new javax.swing.GroupLayout(freeCapacityPanel);
        freeCapacityPanel.setLayout(freeCapacityPanelLayout);
        freeCapacityPanelLayout.setHorizontalGroup(
            freeCapacityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 31, Short.MAX_VALUE)
        );
        freeCapacityPanelLayout.setVerticalGroup(
            freeCapacityPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 28, Short.MAX_VALUE)
        );

        pnBackground.add(freeCapacityPanel);
        freeCapacityPanel.setBounds(75, 294, 31, 28);

        lbFullCapacity.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 14)); // NOI18N
        lbFullCapacity.setForeground(new java.awt.Color(0, 254, 246));
        lbFullCapacity.setText("98 GB");
        pnBackground.add(lbFullCapacity);
        lbFullCapacity.setBounds(186, 252, 130, 14);

        lbFreeCapacity.setFont(new java.awt.Font("Microsoft New Tai Lue", 1, 14)); // NOI18N
        lbFreeCapacity.setForeground(new java.awt.Color(0, 254, 246));
        lbFreeCapacity.setText("82 GB");
        pnBackground.add(lbFreeCapacity);
        lbFreeCapacity.setBounds(186, 302, 130, 14);

        lbBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/background.jpg"))); // NOI18N
        lbBackground.setText("jLabel2");
        pnBackground.add(lbBackground);
        lbBackground.setBounds(0, 0, 1366, 768);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnBackground, javax.swing.GroupLayout.DEFAULT_SIZE, 1366, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnBackground, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(() -> {
            new MainFrame().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javis.StaticImagePanel datePanel;
    private javis.DynamicImagePanel freeCapacityPanel;
    private javis.DynamicImagePanel fullCapacityPanel;
    private javax.swing.JLabel lbBackground;
    private javax.swing.JLabel lbDay;
    private javax.swing.JLabel lbFreeCapacity;
    private javax.swing.JLabel lbFullCapacity;
    private javax.swing.JLabel lbMonth;
    private javax.swing.JPanel pnBackground;
    // End of variables declaration//GEN-END:variables
}