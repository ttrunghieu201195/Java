package javis;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import javax.imageio.ImageIO;

public class StaticImagePanel extends javax.swing.JPanel {
    private BufferedImage img;
    //private String fileName;
    private boolean isStopped;
    private double angle;
    private final double width, height;
    private int r;
    public StaticImagePanel() {
        initComponents();
        img = null;
        r = 0;
        width = super.getWidth();
        height = super.getHeight();
    }

    public void rotateImage(double angle) {
        this.angle = angle * 3.6;
        repaint();
    }

    public void loadImage(String fileName) {
        try {
            fileName = URLDecoder.decode(fileName.replace("file:/", ""), "UTF-8");
            //this.fileName = fileName;
            img = ImageIO.read(new File(fileName));
        } catch (IOException e) {
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (img != null) {
            AffineTransform at = AffineTransform.getTranslateInstance(width, height);
            at.rotate(Math.toRadians(angle), img.getWidth() / 2, img.getHeight() / 2);
            Graphics2D g2d = (Graphics2D) g;
            g2d.drawImage(img, at, null);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                formMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                formMouseExited(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseEntered
        //loadImage(fileName.replace(".png", "_.png"));
        isStopped = false;
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (!isStopped) {
                    rotateImage(r++);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }; thread.start();
    }//GEN-LAST:event_formMouseEntered

    private void formMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseExited
        isStopped = true;
//        loadImage(fileName.replace("_.png", ".png"));
//        repaint();
    }//GEN-LAST:event_formMouseExited

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}