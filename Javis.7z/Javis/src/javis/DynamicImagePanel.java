package javis;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import javax.imageio.ImageIO;

/**
 * @author Duong Nguyen
 */
public class DynamicImagePanel extends javax.swing.JPanel {
    private BufferedImage img;
    private double angle;
    private final double width, height;
    private int r;
    public DynamicImagePanel() {
        initComponents();
        img = null;
        r = 0;
        width = super.getWidth();
        height = super.getHeight();
        startAnimation();
    }

    private void startAnimation() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                while (true) {
                    rotateImage(r++);
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                    }
                }
            }
        }; thread.start();
    }

    private void rotateImage(double angle) {
        this.angle = angle * 3.6;
        repaint();
    }

    public void loadImage(String fileName) {
        try {
            fileName = URLDecoder.decode(fileName.replace("file:/", ""), "UTF-8");
            img = ImageIO.read(new File(fileName));
        } catch (IOException e) {
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (img != null) {
            AffineTransform at = AffineTransform.getTranslateInstance(width, height);
            at.rotate(Math.toRadians(angle), img.getWidth() / 2, img.getHeight() / 2);
            Graphics2D g2d = (Graphics2D) g;
            g2d.drawImage(img, at, null);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}