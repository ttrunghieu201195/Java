package demo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class GifAnimation {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame();
            FrameDragListener frameDrag = new FrameDragListener(frame);
            frame.addMouseListener(frameDrag);
            frame.addMouseMotionListener(frameDrag);
            frame.add(new ImagePanel());
            frame.setUndecorated(true);
            frame.getContentPane().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
            frame.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
            //frame.setType(JFrame.Type.UTILITY);
            
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1366, 768);
            frame.setVisible(true);
        });
    }
}

class ImagePanel extends JPanel {
    Image image;
    public ImagePanel() {
        super.setOpaque(false);
        String path = "D:\\4.Picture\\Icon\\images\\GIF\\tumblr_nwwq08auNz1undzuio1_1280.gif";
        image = Toolkit.getDefaultToolkit().createImage(path);
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image != null) {
            //g.drawImage(image, 0, 0, 1366, 768, this);
            g.drawImage(image, 0, 0, this);
        }
    }
}

class FrameDragListener extends MouseAdapter {
    private final JFrame frame;
    private Point mouseDownCompCoords = null;

    public FrameDragListener(JFrame frame) {
        this.frame = frame;
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        mouseDownCompCoords = null;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        mouseDownCompCoords = e.getPoint();
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Point currCoords = e.getLocationOnScreen();
        frame.setLocation(currCoords.x - mouseDownCompCoords.x, currCoords.y - mouseDownCompCoords.y);
    }
}
